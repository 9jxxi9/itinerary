package test

import "testing"

func TestLookupBasic(t *testing.T) {

}
